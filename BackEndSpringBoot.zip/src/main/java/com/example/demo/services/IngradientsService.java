package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Ingradients;
import com.example.demo.repositories.IngradientsRepository;


@Service
public class IngradientsService {


	@Autowired
	
	IngradientsRepository  ingradientsrpo;
	
	public List<Ingradients> getIngradients()
	{
		return ingradientsrpo.findAll();
	}
	
	public List<Ingradients> AddIngradients(List<Ingradients> ing)
	{
		return  ingradientsrpo.saveAll(ing);
	}

	public Ingradients insertIngradients(Ingradients ing)
	{
		return ingradientsrpo.save(ing);
	}
	public void removeIngradients(int id)
	{
		ingradientsrpo.deleteById(id);
	}


}
