package com.example.demo.services;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Admin;
import com.example.demo.entities.User;
import com.example.demo.repositories.UserRepository;

@Service
public class UserService
{
	@Autowired
	private UserRepository userrepository;

	public UserService() {
		super();
		
	}
	public UserService(UserRepository userrepository) {
		super();
		this.userrepository = userrepository;
	}
	
	public User registerUser(User user)
	{	
		user.setStatus("false");
		Date d1=new Date();
		user.setDateTime(d1);
		return userrepository.save(user);
	}
	public User vlogincheck(User checkuser)
	{
			List<User> users=userrepository.findAll();
			User logincheckuser=null;
			String u=checkuser.getUserName();
			String p=checkuser.getPassword();
			String ut=checkuser.getUserType();
			
			for(User user:users)
			{
				
				if((user.getUserName().equals(u)) && (user.getPassword().equals(p))&&((user.getUserType().equals(ut))) && user.getStatus().equals("true"))							
				{
					logincheckuser=user;
				
				}
			}
			
			return logincheckuser;
		}
		

	public User ulogincheck(User checkuser)
	{
		List<User> users=userrepository.findAll();
		User loginuser=null;
		for(User user:users)
		{
			if(user.getUserName().equals(checkuser.getUserName()) && user.getPassword().equals(checkuser.getPassword()) && user.getUserType().equals(checkuser.getUserType()) && user.getStatus().equals("true"))
			{
				loginuser=user;
				return loginuser;
			}
		}
		return loginuser;
	}
	public void deleteUserById(int id)
	{
		userrepository.deleteById(id);
	}
	public List<User> showAllUsers()
	{
		List<User> users=userrepository.findAll();
		return users;
	}
	public void allowUser(int id)
	{
		Optional<User> user=userrepository.findById(id);
		User newuser=null;
		try
		{
			newuser=user.get();
			newuser.setStatus("true");
			userrepository.save(newuser);
		}
		catch(NoSuchElementException e)
		{
			newuser=null;
		}
	}
	public User forgotPassword(User forgotPasswordUser)
	{
		List<User> users=userrepository.findAll();
		User updatepassworduser=null;
		for(User user:users)
		{
			if(user.getUserName().equals(forgotPasswordUser.getUserName()))
			{
				
					user.setPassword(forgotPasswordUser.getPassword());
					userrepository.save(user);
					
					updatepassworduser=user;
			}
		}
		return updatepassworduser;
		
	}
	public User getfavRecipes(int id)
	{
		User user=userrepository.findById(id).get();
		if(user.getUserID()==id) 
		{
		 
		  return user;
		}
	
		return null;
	}
	public void addToFavList(int uid, int rid) {
		
		userrepository.saveToFav(uid,rid);
		
	}
	public void deleteFromFavList(Integer uid, Integer rid)
	{
		userrepository.deleteFromFav(uid,rid);
	}
}





