package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.entities.Admin;
import com.example.demo.entities.User;
import com.example.demo.repositories.AdminRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminrpo;
	public List<Admin> getAdmin()
	{
		return adminrpo.findAll();
		
	}
	
	public Admin logincheck(Admin checkuser)
	{
		List<Admin> admins=adminrpo.findAll();
		Admin logincheckuser=null;
		for(Admin user:admins)
		{
			if(user.getUserName().equals(checkuser.getUserName()) && user.getPassword().equals(checkuser.getPassword()))
			{
				logincheckuser=user;
			}
		}
		return logincheckuser;
	}

	public Admin forgotPassword(Admin forgotPasswordUser)
	{
		List<Admin> users=adminrpo.findAll();
		Admin admincheck=null;
		for(Admin user:users)
		{
			if(user.getUserName().equals(forgotPasswordUser.getUserName()))
			{
					user.setPassword(forgotPasswordUser.getPassword());
					adminrpo.save(user);
					admincheck=user;
			
			}
		}
		return admincheck;
		
	}
}
