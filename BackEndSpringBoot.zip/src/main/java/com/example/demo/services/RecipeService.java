package com.example.demo.services;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entities.Recipe;

import com.example.demo.repositories.RecipeRepository;


@Service
public class RecipeService implements Serializable{

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    @Autowired
	RecipeRepository reciperpo;

	
	public List<Recipe> getRecipes()
	{
		return  reciperpo.findAll();
	}
	

	public List<Recipe> getByRecipeName(String name)
	{
		
		List<Recipe> listofrecipes= reciperpo.findByRecipeName(name);
		List<Recipe> newlistofrecipes=new ArrayList<Recipe>();
		for(Recipe recipe:listofrecipes)
		{
			if(recipe.getStatus().equals("true"))
			{
				newlistofrecipes.add(recipe);
			}
		}
		return newlistofrecipes;
	}
	
	public void removeRecipe(int id)
	{
		List<Recipe> recipes=reciperpo.findAll();

		for(Recipe r:recipes)
		{
				 reciperpo.deleterecordbyid(id);
				 reciperpo.deleteById(id); 
		}
		
	}
	
	public Recipe addRecipe(Recipe recipe) 
	{
		recipe.setStatus("false");
		Date d1=new Date();
		recipe.setDateTime(d1);
		return reciperpo.save(recipe);
    }

	public Recipe getRecipeById(@RequestParam(value = "id") int id)
	{
		Recipe recipe=reciperpo.findById(id).get();
		
			if(recipe.getRecipeID()==id) 
			{
			 
			  return recipe;
			}
		
			return null;
	}
	
	public List<Recipe> getRecipeByChef(String chefname)
	{
		
		List<Recipe> listofrecipes= reciperpo.findByChefName(chefname);
		List<Recipe> newlistofrecipes=new ArrayList<Recipe>();
		for(Recipe recipe:listofrecipes)
		{
			if(recipe.getStatus().equals("true"))
			{
				newlistofrecipes.add(recipe);
			}
		}
		return newlistofrecipes;
	}
	
	public void allowUploadRecipe(int id)
	{
		Optional<Recipe> recipe=reciperpo.findById(id);
		Recipe newrecipe=null;
		try
		{
			newrecipe=recipe.get();
			newrecipe.setStatus("true");
			reciperpo.save(newrecipe);
		}
		catch(NoSuchElementException e)
		{
			newrecipe=null;
		}
	}

	
	public List<Recipe> getVegRecipes()
	{
		List<Recipe> listofrecipes= reciperpo.findAll();;
		List<Recipe> newlistofrecipes=new ArrayList<Recipe>();
		for(Recipe recipe:listofrecipes)
		{
			if(recipe.getCategoryID()==1  && recipe.getStatus().equals("true"))
			{
				newlistofrecipes.add(recipe);
			}
		}
		return newlistofrecipes;
	}
	
	
	public List<Recipe> getNonVegRecipes()
	{

		List<Recipe> listofrecipes= reciperpo.findAll();
		List<Recipe> newlistofrecipes=new ArrayList<Recipe>();
		for(Recipe recipe:listofrecipes)
		{
			if(recipe.getCategoryID()==2 && recipe.getStatus().equals("true"))
			{
				newlistofrecipes.add(recipe);
			}
		}
		return newlistofrecipes;
	}
	public List<Recipe> displaybydefaultrecipes()
	{
		List<Recipe> listofrecipes= reciperpo.findAll();
		List<Recipe> newlistofrecipes=new ArrayList<Recipe>();
		int count=1;
		for(Recipe recipe:listofrecipes)
		{
			if(recipe.getCategoryID()==1  && recipe.getStatus().equals("true") && count<=5 )
			{
				newlistofrecipes.add(recipe);
				count++;
			}
			if(recipe.getCategoryID()==2  && recipe.getStatus().equals("true") && (count>5 && count <=10) )
			{
				newlistofrecipes.add(recipe);
				count++;
			}
		}
		return newlistofrecipes;
	}
}
