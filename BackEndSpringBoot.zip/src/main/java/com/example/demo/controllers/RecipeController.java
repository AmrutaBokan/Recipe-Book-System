package com.example.demo.controllers;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Recipe;
import com.example.demo.repositories.RecipeRepository;
import com.example.demo.services.RecipeService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
//@RequestMapping("/api/")
public class RecipeController implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	
	RecipeService  recipeService;
	RecipeRepository reciperpo;
		
	
	@RequestMapping("/getallrecipes")
	@ResponseBody
	public List<Recipe> getRecipes()
	{
		return recipeService.getRecipes();
	}
	
	@PostMapping("/addRecipe")  
	@ResponseBody
	public Recipe addRecipe(@RequestBody Recipe recipe) 
	{
		System.out.println("in add Recipe" + recipe);
		
		
		return recipeService.addRecipe(recipe);
		
   }	
	
	@RequestMapping(value="/getbyrecipename" )
	@ResponseBody
	public List<Recipe> getByRecipeName(@RequestParam("name") String name)
	{
		List<Recipe> r = recipeService.getByRecipeName(name);
		return r;
		
	}
	
	@GetMapping("/getbyrecipeid")   
	public Recipe getByRecipeId(@RequestParam("id") int id)
	{
		return recipeService.getRecipeById(id);
	}
	
	
	@RequestMapping("removeRecipeid")  
	@ResponseBody
	public void removeRecipe(@RequestParam(value="id",required=true) int id)
	{
		recipeService.removeRecipe(id);
	}
	
	@RequestMapping("/recipeByChefName")
	@ResponseBody
	public List<Recipe> recipeByChafeName(@RequestParam("name") String chefname)
	{
		List<Recipe> r=recipeService.getRecipeByChef(chefname);
		System.out.println("Found :"+r);
		return r;
	}
	
	@GetMapping("/allowuploadrecipe")
	public void allowUploadRecipe(@RequestParam("id") int id)
	{
		recipeService.allowUploadRecipe(id);
	}
	
	@GetMapping("/getvegrecipes")
	public List<Recipe> getVegRecipes()
	{
		return recipeService.getVegRecipes();
	}
	
	
	@GetMapping("/getnonvegrecipes")
	public List<Recipe> getNonVegRecipes()
	{
		return recipeService.getNonVegRecipes();
	}
	
	@GetMapping("/displaybydefaultrecipes")
	public List<Recipe> displaybydefaultrecipes()
	{
		return recipeService.displaybydefaultrecipes();
	}
	
}
