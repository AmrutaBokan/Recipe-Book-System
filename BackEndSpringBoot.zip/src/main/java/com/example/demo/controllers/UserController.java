package com.example.demo.controllers;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.User;
import com.example.demo.services.UserService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class UserController 
{
	@Autowired
	private UserService userservice;
	
	
	@RequestMapping("/home")
	@ResponseBody
	public String home()
	{
		return "hello";
	}
	
	@PostMapping("/registeruser")
	@ResponseBody
	public User registerUser(@RequestBody User user)
	{
		 return userservice.registerUser(user);
		 
	}
	
	@PostMapping("/viewerlogincheck")
	@ResponseBody
	public User viewerLogincheck(@RequestBody User user)
	{ 
		 return userservice.vlogincheck(user);
	}
	
	@PostMapping("/uploaderlogincheck")
	@ResponseBody
	public User uploaderLogincheck(@RequestBody User user)
	{
		 return userservice.ulogincheck(user);
	}
	@GetMapping("/deleteuserbyid")
	public void deleteUserById(@RequestParam("id") int id)
	{
		userservice.deleteUserById(id);
	}
	
	@RequestMapping("/showalluser")
	public List<User> showAllUsers()
	{
		return userservice.showAllUsers();
	}
	
	@PostMapping("/forgotpassword")
	public  User forgotPassword(@RequestBody User user)
	{
		return userservice.forgotPassword(user);
	}
	@GetMapping("/allowuser")
	public void allowUser(@RequestParam("id") int id)
	{
		userservice.allowUser(id);
	}
	
	@GetMapping("/getfavRecipes")
	public User getfavRecipes(@RequestParam("id") int id)
	{
		return userservice.getfavRecipes(id);
	}
	
	@PostMapping("/addToFav")
	public void AddToFav(@RequestParam("uid") int uid,@RequestParam("rid") int rid)
	{
		userservice.addToFavList(uid,rid);
	}
	@DeleteMapping("/deleteFromFav")
	public void DeleteFromFavList(@RequestParam(value="uid" ,required=true) Integer userid ,@RequestParam(value="rid" ,required=true) Integer recipeid)
	{
		userservice.deleteFromFavList(userid,recipeid);
	}
	
	
}











