package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Admin;
import com.example.demo.entities.User;
import com.example.demo.services.AdminService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class AdminController {

@Autowired
	
	AdminService adminservice;
	
	@GetMapping("/admin")
	public List<Admin> getadmin()
	{
		return adminservice.getAdmin();
		
		
	}
	
	@PostMapping("/adminlogincheck")
	@ResponseBody
	public Admin adminlogincheck(@RequestBody Admin admin)
	{
		 return adminservice.logincheck(admin);
	}
	
	@PostMapping("/adminforgotpassword")
	@ResponseBody
	public Admin adminForgotPassword(@RequestBody Admin admin)
	{
		return adminservice.forgotPassword(admin);
	}

	
	
}
