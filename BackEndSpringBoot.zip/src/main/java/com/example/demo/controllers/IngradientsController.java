package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Ingradients;
import com.example.demo.services.IngradientsService;

@RestController
public class IngradientsController {
	@Autowired
	
	IngradientsService ingradientService;
	
	@GetMapping("/ingradients")
	@ResponseBody
	public List<Ingradients> getIngradients()
	{
		return ingradientService.getIngradients();
		
	}
	@RequestMapping("/ingradients/insert")
	public void AddIngradients(@RequestBody List<Ingradients> ingradient)
	{
		 ingradientService.AddIngradients(ingradient);
	}	
	
	@RequestMapping("/ingradients/add")
	public void insertIngradients(@RequestBody Ingradients ingradients)
	{
		ingradientService.insertIngradients(ingradients);
	}
	
	@DeleteMapping("/ingradients/removebyid")
	public void removeIngradients(@RequestParam("id") int id)
	{
		ingradientService.removeIngradients(id);
	}
	

	
}
