package com.example.demo.repositories;



import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.User;

public interface UserRepository extends JpaRepository<User,Integer> {
	@Modifying
	@Transactional
	@Query(value="insert into user_recipe values(:uid,:rid)",nativeQuery=true)
	public void saveToFav(@Param(value = "uid") int uid, @Param(value = "rid") int rid);

	@Modifying
	@Transactional
	@Query(value="delete from user_recipe  where UserID=:userid AND RecipeID=:recipeid",nativeQuery = true)
	public void deleteFromFav(@Param(value = "userid") Integer userid, @Param(value = "recipeid") Integer recipeid );

}
