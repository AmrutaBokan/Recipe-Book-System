package com.example.demo.repositories;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Recipe;

@Repository
public interface RecipeRepository extends JpaRepository<Recipe, Integer> {

	//List<Recipe> findByrecipeName(String recipeName);

	// public List<Recipe> findByRecipeName(String recipeName);

//	@Query("SELECT r.RecipeID,r.recipeName,i.IngradientsName "
//			+ "from Recipe r, Ingradients i "
//			+ "where r.recipeName=:name")
	
	List<Recipe> findByRecipeName(String name);
	
	
	@Query(value="select * from Recipe  where ChefName=?1",nativeQuery=true)
	List<Recipe> findByChefName(String name);

	@Modifying
	@Transactional
	@Query(value="delete from recipe_ingradients where RecipeID=:id",nativeQuery=true)
	public void deleterecordbyid(@Param("id") int id);
	


	
	
	

}
