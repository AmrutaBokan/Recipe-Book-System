package com.example.demo.entities;


import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="user")
public class User implements Serializable{

	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int UserID;
	
	@Column
	private String UserName; 
	
	@Column
	private String Password; 

	@Column
	private String FirstName;

	@Column
	private String LastName ;

	@Column
	private String EmailID ;

	@Column
	private String ContactNumber; 

	@Column
	private String UserType ; 

	@Column
	private String City ;

	@Column
	private String State;

	@Column
	private String Address;

	@Column
	private Date DateTime;

	@Column
	private String Status;
	
	@JsonIgnoreProperties("user")
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    @JoinTable(name = "user_recipe",
            joinColumns = {
                    @JoinColumn(name = "UserID", referencedColumnName = "UserID",
                            nullable = false, updatable = false)},
            inverseJoinColumns = {
                    @JoinColumn(name = "RecipeID", referencedColumnName = "RecipeID",
                            nullable = false, updatable = false)})
	
       private Set<Recipe> favourite=new HashSet<>();
	
	
	
	public Set<Recipe> getFavourite() {
		return favourite;
	}


	public void setFavourite(Set<Recipe> favourite) {
		this.favourite = favourite;
	}

	public User() {
		super();
	}


	public User(int userID, String userName, String password, String firstName, String lastName, String emailID,
			String contactNumber, String userType, String city, String state, String address, Date dateTime,
			String status) {
		super();
		UserID = userID;
		UserName = userName;
		Password = password;
		FirstName = firstName;
		LastName = lastName;
		EmailID = emailID;
		ContactNumber = contactNumber;
		UserType = userType;
		City = city;
		State = state;
		Address = address;
		DateTime = dateTime;
		Status = status;
	}


	public int getUserID() {
		return UserID;
	}


	public void setUserID(int userID) {
		UserID = userID;
	}


	public String getUserName() {
		return UserName;
	}


	public void setUserName(String userName) {
		UserName = userName;
	}


	public String getPassword() {
		return Password;
	}


	public void setPassword(String password) {
		Password = password;
	}


	public String getFirstName() {
		return FirstName;
	}


	public void setFirstName(String firstName) {
		FirstName = firstName;
	}


	public String getLastName() {
		return LastName;
	}


	public void setLastName(String lastName) {
		LastName = lastName;
	}


	public String getEmailID() {
		return EmailID;
	}


	public void setEmailID(String emailID) {
		EmailID = emailID;
	}


	public String getContactNumber() {
		return ContactNumber;
	}


	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}


	public String getUserType() {
		return UserType;
	}


	public void setUserType(String userType) {
		UserType = userType;
	}


	public String getCity() {
		return City;
	}


	public void setCity(String city) {
		City = city;
	}


	public String getState() {
		return State;
	}


	public void setState(String state) {
		State = state;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public Date getDateTime() {
		return DateTime;
	}


	public void setDateTime(Date dateTime) {
		DateTime = dateTime;
	}


	public String getStatus() {
		return Status;
	}


	public void setStatus(String status) {
		Status = status;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	
	
	
}
