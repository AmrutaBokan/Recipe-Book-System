package com.example.demo.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="ingradients")
public class Ingradients implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int IngradientsID;
	
	@Column(name="IngradientsName")
	private String IngradientsName;
	
	@Column(name="IngradientsType")
	private String IngradientsType;
	
	@Column(name="Measure")
	private String Measure;

	
	@ManyToMany(mappedBy = "ingradients", fetch = FetchType.LAZY)
	private Set<Recipe> recipe=new HashSet<>();
	
	public Ingradients() {
		super();
		
	}

	public Ingradients(int  ingradientsID ,String ingradientsName, String ingradientsType, String measure) {
		super();
		IngradientsID=ingradientsID;
		IngradientsName = ingradientsName;
		IngradientsType = ingradientsType;
		Measure = measure;
	}
	

	public Ingradients(String ingradientsName, String ingradientsType, String measure) {
		super();
		IngradientsName = ingradientsName;
		IngradientsType = ingradientsType;
		Measure = measure;
	}

	public String getIngradientsName() {
		return IngradientsName;
	}

	public void setIngradientsName(String ingradientsName) {
		IngradientsName = ingradientsName;
	}

	public String getIngradientsType() {
		return IngradientsType;
	}

	public void setIngradientsType(String ingradientsType) {
		IngradientsType = ingradientsType;
	}

	public String getMeasure() {
		return Measure;
	}

	public void setMeasure(String measure) {
		Measure = measure;
	}

	public int getIngradientsID() {
		return IngradientsID;
	}

	public void setIngradientsID(int ingradientsID) {
		IngradientsID = ingradientsID;
	}

	@Override
	public String toString() {
		return "Ingradients [IngradientsID=" + IngradientsID + ", IngradientsName=" + IngradientsName
				+ ", IngradientsType=" + IngradientsType + ", Measure=" + Measure + "]";
	}
	
	
}
