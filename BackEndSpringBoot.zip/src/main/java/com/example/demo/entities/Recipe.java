package com.example.demo.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;
@Entity
@Table(name="recipe")

public class Recipe implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int RecipeID;
	
	@Column(name="RecipeName")
	private String recipeName;
	
	@Column(name="RecipeDescription")
	private String RecipeDescription;
	
	@Column(name="Steps")
	private String Step;

	@Column(name="CategoryID")
	private int CategoryID;
	
	@Column(name="DateTime")
	private Date DateTime;
	
	@Column(name="RecipeType")
	private String RecipeType;
	
	@Column(name="NumberOfServing")
	private String NumberOfServing;
	
	@Column(name="PreparationTime")
	private String PreparationTime;
	
	@Column(name="CookingTime")
	private String CookingTime;
	
	@Column(name="ChefName")
	private String chefName;
	
	@Column(name="Status")
	private String Status;
	
	@Column(name="ingradients")
	private String ingradient;
	
	@Column(name="imgurl")
	private String imgurl;
	
	
	
    
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    @JoinTable(name = "recipe_ingradients",
            joinColumns = {
                    @JoinColumn(name = "RecipeID", referencedColumnName = "RecipeID",
                            nullable = false, updatable = false)},
            inverseJoinColumns = {
                    @JoinColumn(name = "IngradientsID", referencedColumnName = "IngradientsID",
                           nullable = false, updatable = false)})
	private Set<Ingradients> ingradients=new HashSet<>();

    
    
    
   
    
    @ManyToMany(mappedBy="favourite",fetch =FetchType.LAZY)
    private Set<User> user=new HashSet<>();
     
    public Set<User> getUser() {
		return user;
	}

	public void setUser(Set<User> user) {
		this.user = user;
	}

	
	public Recipe() {
		super();
		
	}

	public int getRecipeID() {
		return RecipeID;
	}

	public void setRecipeID(int recipeID) {
		RecipeID = recipeID;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public String getRecipeDescription() {
		return RecipeDescription;
	}

	public void setRecipeDescription(String recipeDescription) {
		RecipeDescription = recipeDescription;
	}

	public String getStep() {
		return Step;
	}

	public void setStep(String step) {
		Step = step;
	}

	public int getCategoryID() {
		return CategoryID;
	}

	public void setCategoryID(int categoryID) {
		CategoryID = categoryID;
	}

	public String getRecipeType() {
		return RecipeType;
	}

	public void setRecipeType(String recipeType) {
		RecipeType = recipeType;
	}

	public String getNumberOfServing() {
		return NumberOfServing;
	}

	public void setNumberOfServing(String numberOfServing) {
		NumberOfServing = numberOfServing;
	}

	public String getPreparationTime() {
		return PreparationTime;
	}

	public void setPreparationTime(String preparationTime) {
		PreparationTime = preparationTime;
	}

	public String getCookingTime() {
		return CookingTime;
	}

	public void setCookingTime(String cookingTime) {
		CookingTime = cookingTime;
	}

	public String getChefName() {
		return chefName;
	}

	public void setChefName(String chefName) {
		this.chefName = chefName;
	}

	public Set<Ingradients> getIngradients() {
		return ingradients;
	}

	public void setIngradients(Set<Ingradients> ingradients) {
		this.ingradients = ingradients;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	public Date getDateTime() {
		return DateTime;
	}

	public void setDateTime(Date dateTime) {
		DateTime = dateTime;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	
	

	public String getIngradient() {
		return ingradient;
	}

	public void setIngradient(String ingradient) {
		this.ingradient = ingradient;
	}

	public String getImgurl() {
		return imgurl;
	}

	public void setImgurl(String imgurl) {
		this.imgurl = imgurl;
	}

	@Override
	public String toString() {
		return "Recipe [RecipeID=" + RecipeID + ", recipeName=" + recipeName + ", RecipeDescription="
				+ RecipeDescription + ", Step=" + Step + ", CategoryID=" + CategoryID + ", RecipeType=" + RecipeType
				+ ", NumberOfServing=" + NumberOfServing + ", PreparationTime=" + PreparationTime + ", CookingTime="
				+ CookingTime + ", ChefName=" + chefName + ", ingradients=" + ingradients + "]";
	}

	

	
}
