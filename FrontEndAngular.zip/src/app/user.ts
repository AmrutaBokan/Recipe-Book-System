export class User 
{
    public userID:number;
    public userName:string;
    public password:string;
    public firstName:string;
    public lastName:string;
    public emailID:string;
    public contactNumber:string;
    public userType:string;
    public city:string;
    public state:string;
    public address:string;
    public dateTime:Date;
    public status:string;
    constructor(userID?:any,userName?:any,password?:any,firstName?:any,lastName?:any,emailID?:any,
        contactNumber?:any,userType?:any,city?:any,state?:any,address?:any,dateTime?:any,
        status?:any)
    {
        this.userID=userID;
        this.userName=userName;
        this.password=password;
        this.firstName=firstName;
        this.lastName=lastName;
        this.emailID=emailID;
        this.contactNumber=contactNumber;
        this.userType=userType;
        this.city=city;
        this.state=state;
        this.address=address;
        this.dateTime=dateTime;
        this.status=status;
    }
}