import { Component, OnInit } from '@angular/core';
import { Recipe } from '../recipe';
import { RecipeServiceService } from '../recipe-service.service';

@Component({
  selector: 'app-uploadrecipe',
  templateUrl: './uploadrecipe.component.html',
  styleUrls: ['./uploadrecipe.component.scss']
})
export class UploadrecipeComponent implements OnInit {
   recipe:Recipe;
    data:any;  
    recipeID:any;
    recipeName:any;
    recipeType:any;
    categoryID:any;
    recipeDescription:any;
    step:any;
    numberOfServing:any;
    preparationTime:any;
    cookingTime:any;
    chefName:any;
    imgurl:any;
    ingradient:any;

  constructor(private recipeService:RecipeServiceService) {
    this.recipe=new Recipe();
   }
  

  ngOnInit(): void {
  }

  onSubmit(data1:any)
  {
   
    return this.recipeService.addRecipe(data1).subscribe((x)=>{this.data=x});

  }

}
