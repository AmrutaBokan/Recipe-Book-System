import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewerhomeComponent } from './viewerhome.component';

describe('ViewerhomeComponent', () => {
  let component: ViewerhomeComponent;
  let fixture: ComponentFixture<ViewerhomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewerhomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewerhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
