
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  deleteUserById(id:any)
  {
    return this.http.get("http://localhost:8080/deleteuserbyid?id="+id);
  }

  showAllUsers():Observable<any>
  {
    return this.http.get("http://localhost:8080/showalluser");
  }
  allowUser(id:any)
  {
    return this.http.get("http://localhost:8080/allowuser?id="+id);
  }
  registerUser(data:any):Observable<any>
  {
    return this.http.post("http://localhost:8080/registeruser",data);
  }
  loginCheck(data:any):Observable<any>
  {
    return this.http.post("http://localhost:8080/viewerlogincheck",data);
  }
  forgotpassword(data:any)
  {
    return this.http.post("http://localhost:8080/forgotpassword",data);
  }
  uploaderloginCheck(data:any):Observable<any>
  {
    return this.http.post("http://localhost:8080/uploaderlogincheck",data);
  }
}
