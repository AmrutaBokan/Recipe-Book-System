import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploaderloginComponent } from './uploaderlogin.component';

describe('UploaderloginComponent', () => {
  let component: UploaderloginComponent;
  let fixture: ComponentFixture<UploaderloginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UploaderloginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UploaderloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
