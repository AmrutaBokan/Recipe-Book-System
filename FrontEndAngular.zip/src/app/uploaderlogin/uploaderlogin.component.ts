import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-uploaderlogin',
  templateUrl: './uploaderlogin.component.html',
  styleUrls: ['./uploaderlogin.component.scss']
})
export class UploaderloginComponent implements OnInit {
  data:any;
  userName:any;
  password:any;
  user:User;
  userType:any="Uploader";
  errorMsg:any;

  constructor(private userservice : UserService,private router:Router) { 
    this.user=new User();
    this.errorMsg="";
  }

  ngOnInit(): void {
  }
  
  uploaderloginCheck(formData:any)
  {
    this.userservice.uploaderloginCheck(formData).subscribe((response)=>{console.log(response);
          if(response)
          { 
              this.router.navigate(["/uploaderhome"]);     
          }  
          else
          {
              this.errorMsg="Username or Password Invalid";
          }
          });

  }
}
