import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { RegisterUserComponent } from './register-user/register-user.component';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminforgotpasswordComponent } from './adminforgotpassword/adminforgotpassword.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { ViewerhomeComponent } from './viewerhome/viewerhome.component';
import { UplaoderhomeComponent } from './uplaoderhome/uplaoderhome.component';
import { UploaderloginComponent } from './uploaderlogin/uploaderlogin.component';
import { DisplayreceipeComponent } from './displayreceipe/displayreceipe.component';
import { UploadrecipeComponent } from './uploadrecipe/uploadrecipe.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterUserComponent,
    LoginComponent,
    ForgotpasswordComponent,
    AdminloginComponent,
    AdminforgotpasswordComponent,
    AdminhomeComponent,
    ViewerhomeComponent,
    UplaoderhomeComponent,
    UploaderloginComponent,
    DisplayreceipeComponent,
    UploadrecipeComponent,
   
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
