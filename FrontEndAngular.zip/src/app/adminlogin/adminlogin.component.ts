import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.scss']
})
export class AdminloginComponent implements OnInit {
  userName:any;
  password:any;
  admin:Admin;
  data:any;
  errorMsg:any;
  constructor(private adminservice:AdminService,private router:Router) { 
    this.admin=new Admin();
    this.errorMsg="";
  }

  ngOnInit(): void {
  }
 
  adminloginCheck(formData:any)
  {
    this.adminservice.adminloginCheck(formData).subscribe((response)=>{console.log(response);
        if(response)
        { 
               this.router.navigate(["/adminhome"]);      
        }  
        else{
          this.errorMsg="Username or Password Invalid";
        }
        });
      }
  
}
  

