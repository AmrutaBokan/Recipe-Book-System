import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  data:any;
  userName:any;
  password:any;
  user:User;
  userType:any;
  errorMsg:any;

  constructor(private userservice : UserService,private router:Router) { 
    this.user=new User();
    this.userType="Viewer";
    this.errorMsg="";
  }

  ngOnInit(): void {
  }
  
  loginCheck(formData:any)
  {
    this.userservice.loginCheck(formData).subscribe((response)=>{console.log(response);
        if(response)
          { 
             this.router.navigate(["/viewerhome"]);      
          }  
          else
          {
             this.errorMsg="Username or Password Invalid";
           }
      });
        
  }

   
     
}
