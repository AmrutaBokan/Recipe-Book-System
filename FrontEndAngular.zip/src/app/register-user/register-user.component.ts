import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';



@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.scss']
})
export class RegisterUserComponent implements OnInit {
  user:User;
  data:any;
  userID:any;
  userName:any;
  password:any;
  firstName:any;
  lastName:any;
  emailID:any;
  contactNumber:any;
  userType:any;
  city:any;
  state:any;
  address:any;
  dateTime:any;
  status:any;
 
  constructor(private userservice : UserService) {  
  
    this.user=new User();
  }
  ngOnInit(): void {
  }
  onSubmit(data:any)
  {
    this.userservice.registerUser(data).subscribe((x)=>{this.data=x});
  }
}