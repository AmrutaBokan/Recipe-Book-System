export class Ingradients {

    ingradientsID:string;
    ingradientsName:string;
    ingradientsType:string;
    Measure:string;


    constructor(ingradientid?:any,ingradientname?:any,ingradientstype?:any,measure?:any)
   {
       this.ingradientsID=ingradientid;
       this.ingradientsName=ingradientname;
       this.ingradientsType=ingradientstype;
       this.Measure=measure;
   }
}
