import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayreceipeComponent } from './displayreceipe.component';

describe('DisplayreceipeComponent', () => {
  let component: DisplayreceipeComponent;
  let fixture: ComponentFixture<DisplayreceipeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayreceipeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayreceipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
