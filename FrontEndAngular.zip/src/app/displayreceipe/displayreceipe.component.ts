import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { RecipeServiceService } from '../recipe-service.service';


@Component({
  selector: 'app-displayreceipe',
  templateUrl: './displayreceipe.component.html',
  styleUrls: ['./displayreceipe.component.scss']
})
export class DisplayreceipeComponent implements OnInit {
  data:any;
  recipes:Array<any>;
  

  constructor(private recipeService:RecipeServiceService) {
    this.recipes=new Array<any>();

  }
  
 
  ngOnInit(): void {
    this.getRecipe();
  }
  getRecipe()
  {  
    this.recipeService.getRecipes().subscribe((data)=>{this.recipes=data});
   }

  removeRecipeByid(data:any)
  {
    this.recipeService.removeRecipeByid(data).subscribe((x)=>{this.recipes=x});
  }

}
