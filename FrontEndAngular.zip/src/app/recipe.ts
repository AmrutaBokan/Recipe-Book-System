

export class Recipe {

    recipeID:string;
    recipeName:string;
    recipeType:string;
    categoryID:string;
    recipeDescription:string;
    step:string;
    numberOfServing:string;
    preparationTime:string;
    cookingTime:string;
    chefName:string;
    status:string;
    ingradient:string;
    imgurl:string;
    
   constructor(recipeID?:any,recipeName?:any,recipeType?:any,categoryID?:any,recipeDescription?:any,steps?:any,numberOfServing?:any,
     preparationTime?:any,cookingTime?:any,chefName?:any,status?:any,ingradient?:any,imgurl?:any)
   {
        this.recipeID=recipeID;
        this.recipeName=recipeName;
        this.recipeType=recipeType;
        this.categoryID=categoryID;
        this.recipeDescription=recipeDescription;
        this.step=steps;
        this.numberOfServing=numberOfServing;
        this.preparationTime=preparationTime;
        this.cookingTime=cookingTime;
        this.chefName=chefName;
        this.status=status;
        this.ingradient=ingradient;
        this.imgurl=imgurl;
   }    

}
