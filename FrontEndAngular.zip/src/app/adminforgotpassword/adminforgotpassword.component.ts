import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-adminforgotpassword',
  templateUrl: './adminforgotpassword.component.html',
  styleUrls: ['./adminforgotpassword.component.scss']
})
export class AdminforgotpasswordComponent implements OnInit {
  data:any;
  admin:Admin;
  userName:any;
  password:any;
  constructor(private adminservice:AdminService) { 
    this.admin=new Admin();
  }

  ngOnInit(): void {
  }
  adminforgotpassword(data:any)
  {
    this.adminservice.adminforgotpassword(data).subscribe((x)=>this.data=x);
  }
}
