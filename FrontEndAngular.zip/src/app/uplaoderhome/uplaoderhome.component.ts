import { Component, OnInit } from '@angular/core';
import { RecipeServiceService } from '../recipe-service.service';

@Component({
  selector: 'app-uplaoderhome',
  templateUrl: './uplaoderhome.component.html',
  styleUrls: ['./uplaoderhome.component.scss']
})
export class UplaoderhomeComponent implements OnInit {
  recipenm:any;
  chefname:any;
  data:Array<any>;
  data1:Array<any>;
  nonveg:Array<any>;
  veg:Array<any>;
  defaultrecipe:Array<any>;

  constructor(private recipeService:RecipeServiceService) {
    this.data=new Array<any>(); 
    this.data1=new Array<any>(); 
    this.veg=new Array<any>();
    this.nonveg=new Array<any>();
    this.defaultrecipe=new Array<any>();
  }

  ngOnInit(): void 
  {
    this.displaybydefaultrecipes();
  }
  getRecipesByName(recipeName:any)
  {
    this.recipeService.getRecipesByName(recipeName).subscribe((x)=>{this.data=x});
  }

  getRecipeByChefName(chefName:any)
  {   
    this.recipeService.getRecipeByChefName(chefName).subscribe((x1)=>{this.data1=x1});
  }
  getVegRecipes()
  {
    this.recipeService.getVegRecipes().subscribe((veg)=>{this.veg=veg});
  }
  getNonVegRecipes()
  {
    this.recipeService.getNonVegRecipes().subscribe((nonveg)=>{this.nonveg=nonveg});
  }
  displaybydefaultrecipes()
  {
    this.recipeService.displaybydefaultrecipes().subscribe((n)=>{this.defaultrecipe=n});
  }
}
