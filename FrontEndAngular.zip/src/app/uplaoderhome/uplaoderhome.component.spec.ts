import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UplaoderhomeComponent } from './uplaoderhome.component';

describe('UplaoderhomeComponent', () => {
  let component: UplaoderhomeComponent;
  let fixture: ComponentFixture<UplaoderhomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UplaoderhomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UplaoderhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
