import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminforgotpasswordComponent } from './adminforgotpassword/adminforgotpassword.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { LoginComponent } from './login/login.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import { UplaoderhomeComponent } from './uplaoderhome/uplaoderhome.component';
import { UploaderloginComponent } from './uploaderlogin/uploaderlogin.component';
import { UploadrecipeComponent } from './uploadrecipe/uploadrecipe.component';
import { ViewerhomeComponent } from './viewerhome/viewerhome.component';

const routes: Routes = [
  {path:'adminlogin',component:AdminloginComponent},
  {path:'adminforgotpassword',component:AdminforgotpasswordComponent},
  {path:'adminhome',component:AdminhomeComponent},
  {path:'register',component: RegisterUserComponent},
  {path:'viewerlogin',component: LoginComponent},
  {path:'uploaderlogin',component: UploaderloginComponent},
  {path:'forgotpassword',component: ForgotpasswordComponent},
  {path:'viewerhome',component: ViewerhomeComponent},
  {path:'uploaderhome',component:UplaoderhomeComponent},
  {path:'uploaderrecipe',component:UploadrecipeComponent}
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
