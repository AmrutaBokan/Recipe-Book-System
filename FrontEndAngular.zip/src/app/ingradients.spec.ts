import { Ingradients } from './ingradients';

describe('Ingradients', () => {
  it('should create an instance', () => {
    expect(new Ingradients()).toBeTruthy();
  });
});
