import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.scss']
})
export class ForgotpasswordComponent implements OnInit {
  data:any;
  user:User;
  userName:any;
  password:any;
  constructor(private userservice : UserService) { 
    this.user=new User();
  }

  ngOnInit(): void {
  }
  forgotpassword(data:any)
  {
    this.userservice.forgotpassword(data).subscribe((x)=>{this.data=x});
  }
}
