import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Recipe } from './recipe';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})


export class RecipeServiceService 
{
  constructor(private http : HttpClient) { }

  getRecipes():Observable<Recipe[]>
  {
    return this.http.get<Recipe[]>("http://localhost:8080/getallrecipes");
  }

  addRecipe(data:any):Observable<any>
  {
    
    return this.http.post("http://localhost:8080/addRecipe",data);
  }
  
  getRecipesByName(recipeName:any):Observable<any>
  {
   
    return this.http.get("http://localhost:8080/getbyrecipename?name="+recipeName);
    
  }
   
  getRecipeByChefName(chefName:any):Observable<any>
  {
  return this.http.get("http://localhost:8080/recipeByChefName?name="+chefName);
  }


 removeRecipeByid(id:any):Observable<any>
 {
  return this.http.get("http://localhost:8080/removeRecipeid?id="+id);
 }

 allowuploadrecipe(id:any)
 {
   return this.http.get("http://localhost:8080/allowuploadrecipe?id="+id);
 }

 getNonVegRecipes():Observable<any>
 {
  return this.http.get("http://localhost:8080/getnonvegrecipes");
 }
 getVegRecipes():Observable<any>
 {
  return this.http.get("http://localhost:8080/getvegrecipes");
 }
 displaybydefaultrecipes():Observable<any>
 {
  return this.http.get("http://localhost:8080/displaybydefaultrecipes");

 }

}
