export class Admin
{
    public adminID: number;
    public userName:String;
    public password:String;
    public firstName:String;
    public lastName:String;
    public emailID:String;
    public contactNumber:number;
    public city:String;
    public state:String;
    public address:String;

    constructor(adminID?:any, userName?:any,password?:any,firstName?:any,lastName?:any,emailID?:any,
        contactNumber?:any,city?:any,state?:any,address?:any){
        this.adminID = adminID;
        this.userName=userName;
        this.password=password;
        this.firstName=firstName;
        this.lastName=lastName;
        this.emailID=emailID;
        this.contactNumber=contactNumber;
        this.city=city;
        this.state=state;
        this.address=address;

    }
}