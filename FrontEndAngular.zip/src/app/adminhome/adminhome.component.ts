import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { RecipeServiceService } from '../recipe-service.service';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.scss']
})
export class AdminhomeComponent implements OnInit {
  data:Array<any>;
  user:any;
  user1:any;
  recipe:any;
  recipes:Array<any> ;
  
  constructor(private userservice : UserService,private recipeService:RecipeServiceService) { 
    this.data=new Array<any>();
    this.recipes=new Array<any>();
  }

  ngOnInit(): void {
  }

  showAllUsers()
  {
    this.userservice.showAllUsers().subscribe((data)=>{this.data=data})
  }
  allowUser(userid:any)
  {
   
    this.userservice.allowUser(userid).subscribe((x)=>{this.user=x});
  }
  deleteUserById(userid:any)
  {
    this.userservice.deleteUserById(userid).subscribe((x)=>{this.user1=x});
  }
  getRecipe()
  {  
    this.recipeService.getRecipes().subscribe((x)=>{this.recipes=x});
   }

  removeRecipeByid(data:any)
  {
    this.recipeService.removeRecipeByid(data).subscribe((x)=>{this.recipes=x});
  }
  allowuploadrecipe(recipeid:any)
  {
    this.recipeService.allowuploadrecipe(recipeid).subscribe((x)=>{this.recipe=x});
  }
}
